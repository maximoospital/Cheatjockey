Repo: https://bitbucket.org/avatarlax/ci-cmpc-cotidian/

# Pasos para compilación:

          - composer install --optimize-autoloader
          - composer dump-autoload
          - npm install
          - npm run production

# Set permission:

sudo /usr/bin/php7.1 %APPLICATION_PATH%/artisan twig:clean
mkdir -p %APPLICATION_PATH%/bootstrap/cache
mkdir -p %APPLICATION_PATH%/storage/framework/sessions

mkdir -p %APPLICATION_PATH%/public/uploads
chmod 775 -R %APPLICATION_PATH%/public/uploads
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads -R

mkdir -p %APPLICATION_PATH%/public/uploads/products
chmod 775 -R %APPLICATION_PATH%/public/uploads/products
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads/products -R

mkdir -p %APPLICATION_PATH%/public/uploads/categories
chmod 775 -R %APPLICATION_PATH%/public/uploads/categories
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads/categories -R

mkdir -p %APPLICATION_PATH%/public/uploads/documents
chmod 775 -R %APPLICATION_PATH%/public/uploads/documents
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads/documents -R

mkdir -p %APPLICATION_PATH%/public/uploads/heros
chmod 775 -R %APPLICATION_PATH%/public/uploads/heros
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads/heros -R

mkdir -p %APPLICATION_PATH%/public/uploads/articles
chmod 775 -R %APPLICATION_PATH%/public/uploads/articles
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads/articles -R

mkdir -p %APPLICATION_PATH%/public/uploads/stores
chmod 775 -R %APPLICATION_PATH%/public/uploads/stores
sudo chown admin:www-data %APPLICATION_PATH%/public/uploads/stores -R

sudo chgrp www-data %APPLICATION_PATH%/bootstrap/cache
sudo chmod 775 %APPLICATION_PATH%/bootstrap/cache
sudo chown admin:www-data %APPLICATION_PATH%/storage -R
cd %APPLICATION_PATH%
sudo find . -type d -exec chmod 775 {} \;
sudo find . -type f -exec chmod 664 {} \; 