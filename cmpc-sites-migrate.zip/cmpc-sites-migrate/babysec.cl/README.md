Repo: https://bitbucket.org/avatarlax/ci-cmpc-babysec-unified/
.htaccess file location: /public/.htaccess
database.php file location: application/config/database.php
phinx migrate commnd: ./phinx migrate

# Pasos para la compilación

          - composer install
          - npm install
          - bower install --allow-root
          - gulp prod

# Set permission:
mkdir -p %APPLICATION_PATH%/application/cache
mkdir -p %APPLICATION_PATH%/application/cache/twig
mkdir -p %APPLICATION_PATH%/public/assets/uploads
mkdir -p %APPLICATION_PATH%/public/assets/uploads/images
mkdir -p %APPLICATION_PATH%/public/assets/uploads/product
mkdir -p %APPLICATION_PATH%/public/assets/uploads/product/thumbnail
mkdir -p %APPLICATION_PATH%/public/assets/uploads/product/image
mkdir -p %APPLICATION_PATH%/public/assets/uploads/stores
mkdir -p %APPLICATION_PATH%/public/assets/uploads/stores/image
mkdir -p %APPLICATION_PATH%/public/assets/uploads/category
mkdir -p %APPLICATION_PATH%/public/assets/uploads/lifestage
mkdir -p %APPLICATION_PATH%/public/assets/uploads/lifestage/highlight
mkdir -p %APPLICATION_PATH%/public/assets/uploads/docs
mkdir -p %APPLICATION_PATH%/public/assets/uploads/navigation
mkdir -p %APPLICATION_PATH%/public/assets/uploads/hero
mkdir -p %APPLICATION_PATH%/public/assets/uploads/article
mkdir -p %APPLICATION_PATH%/public/assets/uploads/xls
mkdir -p %APPLICATION_PATH%/public/assets/uploads/warrantyclaims
sudo chgrp www-data -R %APPLICATION_PATH%/application/cache
sudo chgrp www-data -R %APPLICATION_PATH%/public/assets/uploads
sudo chmod 775 -R %APPLICATION_PATH%/application/cache
sudo chmod 775 -R %APPLICATION_PATH%/public/assets/uploads
sudo rm -rf %APPLICATION_PATH%/application/cache/twig/*

rm -rf %APPLICATION_PATH%/public/assets/uploads/document
sudo mkdir -p %APPLICATION_PATH%/public/assets/uploads/documents
sudo chgrp -R www-data %APPLICATION_PATH%/public/assets/uploads/documents
sudo chmod 775 -R %APPLICATION_PATH%/public/assets/uploads/documents

