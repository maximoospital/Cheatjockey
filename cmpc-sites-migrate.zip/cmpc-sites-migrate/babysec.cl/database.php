<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
	'dsn'	=> '',
    'hostname' => getenv('database.default.hostname'),
    'username' => getenv('database.default.username'),
    'password' => getenv('database.default.password'),
    'database' => getenv('database.default.database'),
	'dbdriver' => getenv('database.default.DBDriver'),
	'dbprefix' => getenv('database.default.DBPrefix'),
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => getenv('database.default.cacheOn'),
	'cachedir' => getenv('database.default.cacheDir'),
	'char_set' => getenv('database.default.charset'),
	'dbcollat' => getenv('database.default.DBCollat'),
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);