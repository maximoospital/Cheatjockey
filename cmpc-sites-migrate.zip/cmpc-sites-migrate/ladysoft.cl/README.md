Repo: https://bitbucket.org/avatarlax/ci-cmpc-ladysoft/
.htaccess file path: public/.htaccess

# Set permission:

sudo mkdir -p %APPLICATION_PATH%/application/cache
sudo mkdir -p %APPLICATION_PATH%/application/cache/twig
sudo rm -rf %APPLICATION_PATH%/application/cache/twig/*

sudo mkdir -p %APPLICATION_PATH%/public/assets/uploads
sudo mkdir -p %APPLICATION_PATH%/public/assets/uploads/images
sudo mkdir -p %APPLICATION_PATH%/public/assets/uploads/documents
sudo chown -R admin:www-data %APPLICATION_PATH%/public/assets/uploads
sudo chmod 775 -R %APPLICATION_PATH%/public/assets/uploads

# Compilación
          - php composer.phar install

# Seed migrate command
sudo ./phinx migrate

